import arcpy
import ee
import google.auth
import numpy as np
import nptyping as npt
import requests
import io
import uuid

# ----- ArcGIS Environment Variables -----
arcpy.env.overwriteOutput = True
# arcpy.env.outputCoordinateSystem = filein
# arcpy.env.cellSize = filein

#Use the default credentials created and stored locally; see development notes.

credentials, project = google.auth.default(
    scopes=[
        "https://www.googleapis.com/auth/cloud-platform",
        "https://www.googleapis.com/auth/earthengine",
    ]
)

ee.Initialize(
    credentials.with_quota_project(None),
    project=project,
    opt_url='https://earthengine.googleapis.com' # was https://earthengine-highvolume.googleapis.com
)

#This a test AOI, but eventually will be read from ArcGIS
geojson = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {},
      "geometry": {
        "coordinates": [
          [
            [
              -82.96037322982457,
              40.28167952328519
            ],
            [
              -82.96037322982457,
              40.276420352962106
            ],
            [
              -82.95146897961946,
              40.276420352962106
            ],
            [
              -82.95146897961946,
              40.28167952328519
            ],
            [
              -82.96037322982457,
              40.28167952328519
            ]
          ]
        ],
        "type": "Polygon"
      }
    }
  ]
}

geojsonFc = ee.FeatureCollection(geojson)
region = geojsonFc.geometry() # Is a polygon

#This is a test image but will eventually be any image stored in GEE, and specified in ArcGIS
# landsatImage = ee.Image('LANDSAT/LC09/C02/T1_TOA/LC09_044034_20220111').select(['B4', 'B3', 'B2']).visualize(min=0.02, max=0.4, gamma=1.2).clip(region) 
#landsatImage = ee.Image('LANDSAT/LC09/C02/T1_TOA/LC09_044034_20220111').select(['B4', 'B5', 'B6', 'B7']).clip(region) 
landsatImage = ee.ImageCollection('LANDSAT/LC09/C02/T1_TOA').filterDate('2023-01-01', '2023-03-20').filterBounds(geojsonFc).first()
b4BandType = landsatImage.select('B4').bandTypes()
print(b4BandType.getInfo() )

# Need to know certain info to do the calculations:
# - number of bands needed
# - bit depth of imagery
# - size (pixels and geographic) from the AOI

# Current limits on the API require:
# - overall size of request payload has to be less than 32mb
# - each request must be 1000 px by 10,000 px or smaller

def getBandSizeInBits(bandType):
    return ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.int16() ), 16,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.int32() ), 32,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.int64() ), 64,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.float() ), 32,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.double() ), 64,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.uint16() ), 16,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.uint32() ), 32, 8 # applied to int8, uint8 and anything else!
    ) ) ) ) ) ) )


def fetchPixels(img, bands, geom, scale): 
  #the_crs = img.select('B4').projection().crs() # Need to make this dynamic later
  #crs_transform = img.select('B4').projection().transform() # Need to make this dynamic later

  projObj = img.select('B4').projection() # Need to make this dynamic later, bands can vary!
  proj = projObj.getInfo()
  wkt = img.select('B4').projection().wkt().getInfo()
  the_crs = proj['crs']
  esri_factory_code = the_crs[5:] # drop the 'EPSG:' from front of string
  crs_transform = proj['transform']
  
  print('Projection of the specified image: ' + str(proj))
  print('CRS of the specified image: ' + str(the_crs))

  geomTrans = ee.Algorithms.ProjectionTransform(geom, projObj, 1)
  print('transformed input geometry: ' +  str(geomTrans.getInfo() ))

  # example bands ['B3', 'B8', 'B2', 'B11']
  # image name example 'COPERNICUS/S2_SR/20210109T185751_20210109T185931_T10SEG'

  """ url = img.getDownloadUrl({
    'bands': bands,
    'region': geom,
    'scale': 10, # GEE is capable of receiving lat/lon but having scale in meters
    'crs': 'EPSG:4326', # use lat/lon
    'format': 'NPY'
  }) """

  url = img.getDownloadUrl({
    'bands': bands,
    'region': geomTrans.geometry(),
    'scale': 10, 
    'crs': str(the_crs),
    'format': 'NPY'
  })

  #print(url)
  
  response = requests.get(url) # EE returns a structured array, see https://numpy.org/doc/stable/user/basics.rec.html
  if response.status_code != 200:
     raise requests.exceptions.RequestException(
            f"received the following bad status code: {response.status_code}\nServer message: {response.json()['error']['message']}"
     )
  data = np.load(io.BytesIO(response.content)) 
  #print(data)

  # Try converting this to an Esri raster, which expects a simple numpy array.
  # For now, let's assume all the bands have the same data type
  dimensions = len(bands)
  height, width = data.shape #specified in pixels
  
  # create a new array that is 3D
  simpleArr = np.zeros((height, width, dimensions), dtype=data.dtype[0]) # rows, columns, bands
  #print(simpleArr.shape) # rows, columns, bands
  
  # fill the new array with data from the GEE structured array
  fieldNames = data.dtype.names
  for i in range(dimensions): # zero based
    simpleArr[:, :, i] = np.copy(data[fieldNames[i]]) #Is this actually doing a copy? Or just assiging memory address?
    print(fieldNames[i])
    #print(data[ str(fieldNames[i]) ] )
    
  swappedArr = np.swapaxes(simpleArr,0,2)
  swappedArr = np.swapaxes(swappedArr,1,2)

  # If the input array has three dimensions, it (Esri) returns a multiband raster, where the number of bands equals the 
  # length of the first dimension and the size of the raster is defined by the second and third dimensions (bands, rows, columns).
  
  # print('Using ' + wkt + ' to create Esri raster metadata.')
  
  # sr = arcpy.SpatialReference(esri_factory_code)
  # sr = arcpy.SpatialReference(text=wkt) # NO, need to specify a value.
  esri_factory_code = '32617'
  sr = arcpy.SpatialReference(eval(esri_factory_code) ) # 32617
  arcpy.env.outputCoordinateSystem = sr

  #the_img_geom = img.geometry() # This is the geometry of the ENTIRE Landsat scene
  #print('Image geometry:' + str(the_img_geom.getInfo()) )
  #print('Projection of the image geometry:' + str(the_img_geom.projection().getInfo()) )
  #img_geom_base_cs = the_img_geom.transform(proj=the_crs, maxError=1)
  #print('Projection of the image geometry in image base coodinate system:' + str(img_geom_base_cs.projection().getInfo()) )
  #print(img_geom_base_cs.getInfo() )

  #bounding_coords = ee.List(img_geom_base_cs.bounds(maxError=1, proj=the_crs).coordinates() ) 
  bounding_coords = ee.List(geomTrans.geometry().bounds(maxError=1, proj=the_crs).coordinates() ) 
  #print(bounding_coords.getInfo() )
  # need to find bottom left corner for Esri. Seems to be the first element of the list.
  bl_x = bounding_coords.flatten().get(0).getInfo()
  bl_y = bounding_coords.flatten().get(1).getInfo()

  # bl_x = bottom_left_lat.transform(proj=the_crs, maxError=10)
  # bl_y = bottom_left_lat.transform(proj=the_crs, maxError=10)

  print('Bottom left corner: ' + str(bl_y) + ', ' + str(bl_x) )
  myRaster = arcpy.NumPyArrayToRaster(swappedArr, lower_left_corner=arcpy.Point(float(bl_x), float(bl_y)), x_cell_size=10, y_cell_size=10 ) 
  #myRaster = arcpy.NumPyArrayToRaster(swappedArr)
  
  # generate a unique filename
  unique_filename = str(uuid.uuid4())
  print(unique_filename)
    
  # Need to save the raster to disk before doing projection related processing.
  file_string = 'E:/desktop_engine_exports/test_img_' + unique_filename + '.tif' 
  myRaster.save(file_string)
  arcpy.DefineProjection_management(file_string, sr)
  #return data
  return file_string


# raster = arcpy.Raster(fetchPixels(landsatImage, ['B4','B5','B6'], region, 5)) # instantiates from file name string

raster = arcpy.Raster(fetchPixels(landsatImage, ['B4','B5','B6'], region, 5)) # instantiates from file name string

#print(getBandSizeInBits(b4BandType).getInfo() )

#raster.save("E:/desktop_engine_exports/myRandomRaster.tif")

# Try converting this to an Esri raster
# If the input array has three dimensions, it returns a multiband raster, where the number of bands equals the 
# length of the first dimension and the size of the raster is defined by the second and third dimensions (bands, rows, columns).

# myRaster = arcpy.NumPyArrayToRaster(np_data)
# myRaster.save("E:/desktop_engine_exports/myRandomRaster")
