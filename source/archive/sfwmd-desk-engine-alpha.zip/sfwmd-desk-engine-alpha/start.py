# -*- coding: utf-8 -*-
"""
Created on Thu Oct 13 16:15:17 2022

@author: hutch
"""

import arcpy
import ee

ee.Authenticate()
ee.Initialize()

exportRegion = ee.Geometry.BBox(-122.9, 37.1, -121.2, 38.2)

landsatImage = (ee.Image('LANDSAT/LC09/C02/T1_TOA/LC09_044034_20220111').select(['B4', 'B3', 'B2']).visualize(min=0.02, max=0.4, gamma=1.2).clip(exportRegion) )

 
task = ee.batch.Export.map.toCloudStorage(
  image=landsatImage,
  description='mapTilesForEE_SanFrancisco_2',
  bucket='gee-esri-test',  
  fileFormat='auto',
  maxZoom=13,
  region=exportRegion,
  writePublicTiles=True
)

task.start()
