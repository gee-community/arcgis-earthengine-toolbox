import arcpy
import ee
import google.auth

import numpy as np
import nptyping as npt
import requests
import io
import uuid

# ----- ArcGIS Environment Variables -----
arcpy.env.overwriteOutput = True

# ----------------------------------------

credentials, project = google.auth.default(
    scopes=[
        "https://www.googleapis.com/auth/cloud-platform",
        "https://www.googleapis.com/auth/earthengine",
    ]
)

ee.Initialize(
    credentials.with_quota_project(None),
    project=project,
    opt_url='https://earthengine-highvolume.googleapis.com'
)

#collection = ee.ImageCollection('projects/hutch-sandbox/assets/luxparcel/ps_biweekly_sen2_normalized_analytic_subscription_2021-06-14_2021-06-28_mosaic')
#print(collection.getInfo() )

# Region of interest.
coords = [
    -121.58626826832939,
    38.059141484827485,
]
region = ee.Geometry.Point(coords)

# Get a Sentinel-2 image.
image = (ee.ImageCollection('COPERNICUS/S2')
  .filterBounds(region)
  .filterDate('2020-04-01', '2020-09-01')
  .sort('CLOUD_COVERAGE_ASSESSMENT')
  .first())
image_id = image.getInfo()['id']

# Make a projection to discover the scale in degrees.
proj = ee.Projection('EPSG:4326').atScale(10).getInfo()

# Get scales out of the transform.
scale_x = proj['transform'][0]
scale_y = -proj['transform'][4]

# Make a request object.
request = {
    'assetId': image_id,
    'fileFormat': 'NPY',
    'bandIds': ['B4', 'B3', 'B2'],
    'grid': {
        'dimensions': {
            'width': 640,
            'height': 640
        },
        'affineTransform': {
            'scaleX': scale_x,
            'shearX': 0,
            'translateX': coords[0],
            'shearY': 0,
            'scaleY': scale_y,
            'translateY': coords[1]
        },
        'crsCode': proj['crs'],
    },
    'visualizationOptions': {'ranges': [{'min': 0, 'max': 3000}]},
}

data = ee.data.getPixels(request)

# Do something with the image...

# Use my existing code to convert numpy response to geotiff
# Try converting this to an Esri raster, which expects a simple numpy array.
  
# For now, let's assume all the bands have the same data type
dimensions = len(bands)
height, width = data.shape #specified in pixels
  

