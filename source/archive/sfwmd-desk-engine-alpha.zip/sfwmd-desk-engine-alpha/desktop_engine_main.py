#import required modules including open source and from arcpy
#remember any open source module must be included with ArcGIS Pro or added into the environment
import arcpy
import ee
import google.auth
import json
from osgeo import gdal
from osgeo import ogr
from osgeo import osr
import os

#print(os.environ) - yes the GDAL environment variables are set to find the projection data etc.

testSR = osr.SpatialReference()
res = testSR.ImportFromEPSG(32610)
if res != 0:
    raise RuntimeError(repr(res) + ': could not import from EPSG')
#print(testSR.ExportToPrettyWkt() )

#----------------------------------------------------------------------------------------------------
# Parameters provided to the script - These will be set to ArcGIS GUI inputs
FULL_ASSET_NAME = "projects/earthengine-public/assets/LANDSAT/LC09/C02/T1_TOA/LC09_044034_20220111"
OUTPUT_GEOTIFF_FILE = "E:\\desktop_engine_exports\\clipped_gee_asset.tif"
GEOJSON_EPSG = 4326

#shapefile = "E:\\desktop_engine_exports\\aoi\\POLYGON.shp"

#shp_drv = ogr.GetDriverByName('ESRI Shapefile')
#cut_ds = shp_drv.Open(Shapefile, 0) # 0=Read-only, 1=Read-Write
#cut_layer = cut_ds.GetLayer()

#SHAPEFILE_LOCAL = ogr.Open(input_shapefile)
#shp_ds = gdal.OpenEx(shapefile, gdal.GA_ReadOnly)
#cutline_layer = shapefile.GetLayer()
#shp_layer = shp_ds.GetLayerByIndex(0)
#print('The layer is named: {n}\n'.format(n=cutline_layer.GetName()))
#cutline_feature = layer.GetFeature(0)
#spatial_ref = cutline_layer.GetSpatialRef()
#proj4 = spatial_ref.ExportToProj4()
#print('Layer projection is: {proj4}\n'.format(proj4=proj4))

GEOJSON_AOI = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {},
      "geometry": {
        "coordinates": [
          [
            [
              -122.44805090992816,
              37.87323765952179
            ],
            [
              -122.44805090992816,
              37.85199045974289
            ],
            [
              -122.41614344378331,
              37.85199045974289
            ],
            [
              -122.41614344378331,
              37.87323765952179
            ],
            [
              -122.44805090992816,
              37.87323765952179
            ]
          ]
        ],
        "type": "Polygon"
      }
    }
  ]
}

#----------------------------------------------------------------------------------------------------
# Authenticate and initialize GEE
# Remember to set up GCP Application Default Credentials (ADC) before running this code
# Because this script is only for Windows, an example location would be:
# C:\Users\Hutchinson\AppData\Roaming\gcloud\application_default_credentials.json
# which is the same as: %APPDATA%\gcloud\application_default_credentials.json

credentials, project = google.auth.default(
    scopes=[
        "https://www.googleapis.com/auth/cloud-platform",
        "https://www.googleapis.com/auth/earthengine",
    ]
)
print("GCP credentials and project determined.")
ee.Initialize(
    credentials.with_quota_project(None),
    project=project,
)
print("GEE initialized.")
#----------------------------------------------------------------------------------------------------
# Ensure GDAL has the key needed for using the GEE driver. This is the same key as used above.
# Need to provide the location dynamically using:
# %APPDATA%\gcloud\application_default_credentials.json

appdata_folder = os.getenv('APPDATA')
adc_file_path = appdata_folder + "\\gcloud\\application_default_credentials.json"
print("Using GCP ADC credentials: " + adc_file_path)

gdal.UseExceptions()    # Enable exceptions
gdal.SetConfigOption("GOOGLE_APPLICATION_CREDENTIALS", adc_file_path)

proj_lib = os.getenv('PROJ_LIB')
print(proj_lib)

#----------------------------------------------------------------------------------------------------
# Open the GEE asset using the GDAL driver for it:
gdal_uri = "EEDAI:"+FULL_ASSET_NAME
print(gdal_uri)
gee_dataset = gdal.Open(gdal_uri, gdal.GA_ReadOnly)
if gee_dataset is None:
    print("Error opening GEE raster via GDAL")

#----------------------------------------------------------------------------------------------------
img_ee = ee.Image(FULL_ASSET_NAME)
print(img_ee.select('B3').projection().getInfo() )

#----------------------------------------------------------------------------------------------------
# Set up everything needed prior to performing the gdalwarp call
#When loading GeoJSON data into GDAL, only the geometry section of the Feature is needed
json_feature = GEOJSON_AOI['features'][0]
json_geom = str(json_feature['geometry']) #in GeoJSON

geom_obj = ogr.CreateGeometryFromJson(json_geom)
print(geom_obj)

sr = osr.SpatialReference()
#sr.ImportFromEPSG(GEOJSON_EPSG)
sr.ImportFromEPSG(4326) #this change made no difference
print(sr.ExportToPrettyWkt() )

drv = ogr.GetDriverByName('ESRI Shapefile')
feature_ds = drv.CreateDataSource('/vsimem/memory_name.shp')
feature_layer = feature_ds.CreateLayer("layer", srs=sr ,geom_type=ogr.wkbPolygon)

featureDefnHeaders = feature_layer.GetLayerDefn()
outFeature = ogr.Feature(featureDefnHeaders)

outFeature.SetGeometry(geom_obj)
feature_layer.CreateFeature(outFeature)     
#feature_ds.FlushCache()
feature_ds.SyncToDisk()
#feature_ds = None
print(feature_ds)

spatial_ref = feature_layer.GetSpatialRef()
proj4 = spatial_ref.ExportToProj4()
print('Bounding box layer (in-memory) is: {proj4}\n'.format(proj4=proj4))

print('Name of the cutline layer is: ' + feature_layer.GetName() )

#----------------------------------------------------------------------------------------------------
# Call the gdalwarp function
print("Beginning gdalwarp processing.")
print("Using file name: " + OUTPUT_GEOTIFF_FILE)

# Need to use the dstSRS below otherwise in Windows/ArcGIS Pro GDAL it defaults to using a projected Easting and Northing
# That is a difference from Linux.

#warp = gdal.Warp(OUTPUT_GEOTIFF_FILE, gee_dataset, cutlineDSName=shp_ds, cropToCutline=True, dstSRS='EPSG:4326')
#warp = gdal.Warp(OUTPUT_GEOTIFF_FILE, gee_dataset, cutlineDSName=shp_ds, cutlineLayer=shp_layer, cropToCutline=True, dstSRS='EPSG:4326')
#warp = gdal.Warp(OUTPUT_GEOTIFF_FILE, gee_dataset, cutlineDSName='/vsimem/memory_name.shp', cropToCutline=True, srcSRS='EPSG:32610')
#warp = gdal.Warp(OUTPUT_GEOTIFF_FILE, gee_dataset, dstSRS='EPSG:4326') # this works correctly and returns an entire Landsat scene
#warp = gdal.Warp(OUTPUT_GEOTIFF_FILE, gee_dataset, cutlineDSName='/vsimem/memory_name.shp', cutlineLayer='memory_name', cropToCutline=True)

warp = gdal.Warp(OUTPUT_GEOTIFF_FILE, gee_dataset, cutlineDSName="/vsimem/memory_name.shp", cropToCutline=True) # this works correctly in Linux for clipping
warp = None

print("Processing complete.")