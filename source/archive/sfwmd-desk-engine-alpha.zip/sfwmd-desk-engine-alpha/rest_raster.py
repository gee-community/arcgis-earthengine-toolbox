# -*- coding: utf-8 -*-
"""
Created on Fri Nov 11 11:12:13 2022

@author: Hutchinson
"""

import arcpy
import ee
import os
import google.auth
from google.auth.transport.requests import AuthorizedSession
from google.auth import compute_engine

# This is for GCP in gneral, including storage
credentials, project = google.auth.default()
#cloudCredentials, project = google.auth.load_credentials_from_file(filename='C:/Users/Hutchinson/AppData/Roaming/gcloud/application_default_credentials.json', quota_project_id='hutch-sandbox')
session = AuthorizedSession(credentials)

# This specific to GEE
ee.Authenticate(auth_mode='appdefault')
#ee.Initialize(credentials=cloudCredentials, opt_url='https://earthengine-highvolume.googleapis.com', project='hutch-sandbox')
ee.Initialize(opt_url='https://earthengine-highvolume.googleapis.com')


url = 'https://earthengine.googleapis.com/v1beta/projects/earthengine-public/assets/LANDSAT'
response = session.get(url)

from pprint import pprint
import json
#pprint(json.loads(response.content))

collection = ee.ImageCollection('projects/hutch-sandbox/assets/luxparcel/ps_biweekly_sen2_normalized_analytic_subscription_2021-06-14_2021-06-28_mosaic')

# Eventually this would be a polygon in Esri format, which we would create an EE geometry from
# Using the GeoJSON below only as an example to get started. 

geojson = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {},
      "geometry": {
        "coordinates": [
          [
            [
              -82.96037322982457,
              40.28167952328519
            ],
            [
              -82.96037322982457,
              40.276420352962106
            ],
            [
              -82.95146897961946,
              40.276420352962106
            ],
            [
              -82.95146897961946,
              40.28167952328519
            ],
            [
              -82.96037322982457,
              40.28167952328519
            ]
          ]
        ],
        "type": "Polygon"
      }
    }
  ]
}

geojsonFc = ee.FeatureCollection(geojson)
#print('FeatureCollection from GeoJSON' + str(geojsonFc.getInfo() ) )

region = geojsonFc.geometry() # Is a polygon

#print(str(region.getInfo() ) )

landsatImage = ee.Image('LANDSAT/LC09/C02/T1_TOA/LC09_044034_20220111').select(['B4', 'B3', 'B2']).visualize(min=0.02, max=0.4, gamma=1.2).clip(region) 


def getBandSizeInBits(bandType):
    return ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.int16() ), 16,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.int32() ), 32,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.int64() ), 64,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.float() ), 32,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.double() ), 64,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.uint16() ), 16,
    ee.Algorithms.If(ee.Algorithms.IsEqual(bandType, ee.PixelType.uint32() ), 32, 8 # applied to int8, uint8 and anything else!
    ) ) ) ) ) ) )

# Function to iterate over the bands of the image adding up their size in bytes
""" def getPixelSizeInBits(img):
    bandTypes = ee.Image(img).bandTypes()
    keys = bandTypes.keys()
    
    pixelSize = keys.iterate( 
    (lambda bandName, previousSize:
      bandType = bandTypes.get( bandName ) # Get pixel type for the band bandName
      size = getBandSizeInBits( bandType )
      return ee.Number(previousSize).add( size )), ee.Number(0)
  )
  return pixelSize """
    

bandTypes = landsatImage.bandTypes()
keys = bandTypes.keys()
bandType = bandTypes.get('vis-red')
size = getBandSizeInBits(bandType)
print(ee.Number(size).getInfo() )
