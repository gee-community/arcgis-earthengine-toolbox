from osgeo import gdal
from osgeo import ogr
import json
from osgeo import osr

print(gdal.__version__)
gdal.UseExceptions()    # Enable exceptions

gdal.SetConfigOption("GOOGLE_APPLICATION_CREDENTIALS", "C:\\Users\\Hutchinson\\keys\\hutch-sandbox-e6de2d685b26.json")

gee_dataset = gdal.Open("EEDAI:projects/earthengine-public/assets/LANDSAT/LC09/C02/T1_TOA/LC09_044034_20220111", gdal.GA_ReadOnly)
if gee_dataset is None:
   print("Error opening GEE raster via GDAL")

print(gee_dataset)

geojson_aoi = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {},
      "geometry": {
        "coordinates": [
          [
            [
              -122.44805090992816,
              37.87323765952179
            ],
            [
              -122.44805090992816,
              37.85199045974289
            ],
            [
              -122.41614344378331,
              37.85199045974289
            ],
            [
              -122.41614344378331,
              37.87323765952179
            ],
            [
              -122.44805090992816,
              37.87323765952179
            ]
          ]
        ],
        "type": "Polygon"
      }
    }
  ]
}

  
#When loading GeoJSON data into GDAL, only the geometry section of the Feature is needed
json_feature = geojson_aoi['features'][0]
json_geom = str(json_feature['geometry']) #in GeoJSON

geom_obj = ogr.CreateGeometryFromJson(json_geom)

sr = osr.SpatialReference()
sr.ImportFromEPSG(4326)

drv = ogr.GetDriverByName('ESRI Shapefile')
feature_ds = drv.CreateDataSource("/vsimem/memory_name.shp")
feature_layer = feature_ds.CreateLayer("layer",sr ,geom_type=ogr.wkbPolygon)

featureDefnHeaders = feature_layer.GetLayerDefn()
outFeature = ogr.Feature(featureDefnHeaders)

outFeature.SetGeometry(geom_obj)
feature_layer.CreateFeature(outFeature)     
feature_ds.FlushCache()

print("Beginning gdalwarp processing.")

gdal.Warp("E:\\desktop_engine_exports\\sample_gee_clip.tif", 
          gee_dataset,
          cutlineDSName="/vsimem/memory_name.shp", 
          cropToCutline=True)

print("Processing complete.")