import arcpy
import ee
import os
import google.auth
from google.auth.transport.requests import AuthorizedSession
from google.auth import compute_engine

cloudCredentials, project = google.auth.load_credentials_from_file(filename='C:/Users/Hutchinson/AppData/Roaming/gcloud/application_default_credentials.json', scopes=['https://www.googleapis.com/auth/cloud-platform', 'https://www.googleapis.com/auth/devstorage.full_control', 'https://www.googleapis.com/auth/earthengine'])

#credentials, project_id = google.auth.default()

#ee.Authenticate(auth_mode='appdefault')
#ee.Authenticate()

#ee.Initialize(cloudCredentials)

#ee.Initialize(opt_url='https://earthengine.googleapis.com')

#session = AuthorizedSession(cloudCredentials)


ee.Initialize(cloudCredentials, project='hutch-sandbox')

""" from google.cloud import storage
storage_client = storage.Client()
# This code is optional and only used as a connection/permissions test
buckets = storage_client.list_buckets()
print("Buckets:")
for bucket in buckets:
  print(bucket.name) """
