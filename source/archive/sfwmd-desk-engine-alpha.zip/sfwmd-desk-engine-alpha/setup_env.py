# -*- coding: utf-8 -*-
"""
Created on Wed Oct 19 11:51:00 2022

@author: hutch
"""

import arcpy
import ee
import os

def ScriptTool(param0):
    # Script execution code goes here
    pythonPath = sys.path #already a list
    systemPath = os.getenv('PATH')
    
    systemPathSplit = systemPath.split(';') #returns a list
    sys.path.append(systemPathSplit)
    #pythonPath.extend(systemPathSplit) #modify var in place
    #sys.path = list(set(pythonPath)) #remove duplicates
    
    ee.Authenticate(authorization_code=None, quiet=False, code_verifier=None, auth_mode='gcloud')
    ee.Initialize()
    return

# This is used to execute code if the file was run but not imported
if __name__ == '__main__':

    # Tool parameter accessed with GetParameter or GetParameterAsText
    param0 = arcpy.GetParameterAsText(0)
    #param1 = arcpy.GetParameterAsText(1)
    
    ScriptTool(param0)
    
    # Update derived parameter values using arcpy.SetParameter() or arcpy.SetParameterAsText()
