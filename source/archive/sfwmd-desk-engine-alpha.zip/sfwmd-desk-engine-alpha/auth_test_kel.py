import arcpy
import ee
import google.auth

credentials, project = google.auth.default(
    scopes=[
        "https://www.googleapis.com/auth/cloud-platform",
        "https://www.googleapis.com/auth/earthengine",
    ]
)

ee.Initialize(
    credentials.with_quota_project(None),
    project=project,
)

collection = ee.ImageCollection('projects/hutch-sandbox/assets/luxparcel/ps_biweekly_sen2_normalized_analytic_subscription_2021-06-14_2021-06-28_mosaic')
print(collection.getInfo() )
