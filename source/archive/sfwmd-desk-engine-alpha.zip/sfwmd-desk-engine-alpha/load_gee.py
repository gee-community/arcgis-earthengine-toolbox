import arcpy
from osgeo import gdal

driver = gdal.GetDriverByName('EEDAI')
driver.Register()

metadata = driver.GetMetadata() # optional, useful test
print(metadata)

#src_filename = "EEDAI:projects/earthengine-public/assets/COPERNICUS/S2/20170430T190351_20170430T190351_T10SEG" # how to set for GEE?
#dst_filename = "/tmp/xx_geotiff_copy.tif" # the local file we want to create

#src_ds = gdal.Open( src_filename )
#dst_ds = driver.CreateCopy( dst_filename, src_ds, 0 )
